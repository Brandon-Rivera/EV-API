const config = {
    host : 'db-vacacionestwo.cylbb1hnlvm7.us-east-1.rds.amazonaws.com',
    user : 'admin',
    password: 'Cisco123',
    database: 'BAMX'
    };

    /*host : 'localhost',
    user : 'root',
    password: '',
    database: 'bamx'
    };*/

module.exports = config;